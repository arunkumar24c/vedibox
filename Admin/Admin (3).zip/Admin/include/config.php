<?php


$CONF = $TMPL = array();

// The MySQL credentials
$CONF['host'] = 'localhost';
$CONF['user'] = 'root';
$CONF['pass'] = '';
$CONF['name'] = 'vedibox_new';

// The Installation URL
$CONF['url'] = 'http://localhost/Working/SmileMobility/ERPWORK/ERP';

// The Notifications e-mail
$CONF['email'] = 'erp@smilemobility.in';

$CONF['dateformat'] = 'd/m/Y';
$CONF['datetime'] = 'd/M/Y H:i:s';


?>